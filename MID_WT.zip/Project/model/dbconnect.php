<?php

    $db_server="localhost";
    $db_uname="root";
    $db_pass="";
    $db_name="miniproject";

    $conn = mysqli_connect($db_server, $db_uname, $db_pass, $db_name);
?>