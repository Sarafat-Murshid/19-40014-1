<?php 
	header("location: views/Login.php")
?>