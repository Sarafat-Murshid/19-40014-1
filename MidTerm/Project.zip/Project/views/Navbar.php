<?php
echo '<a href="Login.php">Login</a> -
<a href="registration.php">Registration</a>';
?>