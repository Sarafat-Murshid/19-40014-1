<?php
echo '<a href="Welcome.php">Home</a> -
	  <a href="accounts.php">Accounts</a>-
	  <a href="checkbal.php">Balance</a>-
	  <a href="../controller/Logout.php">Logout</a>';
?>